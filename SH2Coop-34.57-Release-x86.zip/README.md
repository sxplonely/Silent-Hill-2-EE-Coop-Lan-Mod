# SH2Coop 34.57 — Release x86 (public testing build)

Cooperativo experimental para 1–4 jugadores de Silent Hill 2 PC (2001/2002) con Enhanced Edition. No es para el remake. Incluye lobby ImGui, conexión directa/LAN, réplicas de jugadores, sincronización de enemigos y guardados cooperativos separados. No se ha validado toda la campaña ni todos los jefes.

## Corrección de distribución 34.57
Corrige la reconstrucción tardía del menú cuando existen partidas individuales: evita perder la opción cooperativa y duplicar ESCENAS. Separa el texto MULTIJUGADOR y permite hacer clic en él; volver del lobby deja seleccionada la opción cooperativa. Conserva los recursos y diseño del lobby anterior. La tabla de servidores reserva espacio para mostrar completo el botón UNIRSE.

Esta entrega corresponde a la primera etapa. P2P global y Born from a Wish completo siguen pendientes. No instalar sobre la instalación personal estable del desarrollador. Verificar primero en la segunda PC.

## Requisitos
- Una copia propia y funcional de Silent Hill 2 PC con Enhanced Edition. Instalar EE desde https://enhanced.townofsilenthill.com/SH2/ . El juego y EE NO están incluidos.
- Windows 10/11. Proceso del juego de 32 bits; usar este mod x86 aunque Windows sea de 64 bits.
- Ejecutable soportado, SHA256: F31A221779FADCA4DAE8FE758546ECDE8B88A88FA6E80FAD7DEE115D2EF620E8. No se incluyen ni descargan ejecutables del juego.
- EE probado: d3d8.dll 3.0.2218.0. Todos deben tener el mismo ejecutable, versión de EE y paquete SH2Coop.
- Permisos de escritura en la carpeta del juego para logs y data/save_coop. Evitar Program Files si impide escribir.
- SH2Coop se compila /MT Release: NO requiere instalar Visual Studio ni copiar VCRUNTIME/MSVCP de una máquina de desarrollo. Los requisitos propios de EE y del juego siguen siendo necesarios.

## Instalación
1. Cierra el juego. Haz copia de tus partidas y del mod anterior si existe.
2. Extrae TODO el contenido de este ZIP en la carpeta que contiene sh2pc.exe. Deben quedar SH2Coop.asi al lado del EXE y plugins/SH2Coop debajo. No coloques el ASI dentro de plugins/SH2Coop.
3. En tu d3d8.ini existente, sección [Plugins], comprueba LoadPlugins = 1 y LoadFromScriptsOnly = 0. Activa también d3d8to9 = 1 en [DirectX] para el lobby ImGui. No reemplaces el INI completo. Busca las claves existentes; no las dupliques. Si aparecen en otra sección, conserva la sección original de EE.
4. Evita copias duplicadas de SH2Coop.asi en otras rutas que lea tu cargador. No se necesita otro ASI loader, Xidi, dinput8.dll ni el mod de cámara para ejecutar SH2Coop.
5. Abre sh2pc.exe. Selecciona MULTIJUGADOR en el título o usa F8. Debe aparecer el lobby. Verify-Install.ps1 permite comprobar archivos y requisitos sin modificar nada.

## Conexión
- Anfitrión: CREAR SERVIDOR → CREAR SALA PUBLICA (LAN) o CREAR SALA PRIVADA (PIN).
- Invitados: buscar la sala pública o UNIRSE A PARTIDA PRIVADA e introducir IPv4:7777#PIN. Para servidor público por dirección, usa IPv4:7777 sin PIN.
- El anfitrión inicia NUEVA PARTIDA cuando estén presentes los participantes, hasta cuatro.
- Permitir TCP 7777 y UDP 7777 para sh2pc.exe en la red utilizada. El descubrimiento automático es LAN, no un listado público mundial.
- Para distancia/Internet se requiere conectividad directa (puerto del host accesible) o una VPN que conecte las redes. No hay relay/NAT traversal automático. Esta distribución no garantiza conexiones a través de CGNAT. Las pruebas locales no equivalen a una prueba entre dos ISP.
- F9 abre guardados cooperativos. Se crean en data/save_coop; no se distribuyen partidas, UUID, PIN ni perfiles predefinidos. No reemplaces data/save con archivos del mod. La validación completa de guardado/campaña sigue pendiente.

## Archivos y dependencias
SH2Coop.asi: plugin Release x86 con ImGui y runtime C++ integrados.
plugins/SH2Coop/bin/SDL3.dll: SDL 3.4.16 x86 oficial, backend opcional de mandos. Carga desde esta ruta explícita o reutiliza SDL3 ya cargada por otro plugin. Teclado/XInput funcionan sin SDL. No copiar SDL x64.
plugins/SH2Coop/assets/lobby/background.png y map-preview.png: recursos del diseño anterior del lobby, conservados desde assets/lobby del proyecto.
plugins/SH2Coop/SH2Coop.ini: EnemySync=1. No contiene rutas ni direcciones personales.
Se utiliza Georgia 22 px de la carpeta de Windows detectada en cada equipo; no se redistribuye la fuente. Si no está disponible, se usa la fuente integrada de ImGui. No existe una ruta C:/Windows fija.
Dependencias Windows del ASI: WS2_32, bcrypt, VERSION, USER32, ole32, KERNEL32, SHELL32, IMM32. SDL3: SETUPAPI, WINMM, IMM32, VERSION, KERNEL32, USER32, GDI32, ADVAPI32, SHELL32, ole32, OLEAUT32. No distribuyas DLL del sistema.
Direct3D9/WIC y XInput son servicios/componentes de Windows usados por el mod; d3d8.dll de EE proporciona la integración de render. La cámara OTS es un mod independiente y no está incluida.

## Solución de problemas
- No aparece MULTIJUGADOR: revisar d3d8.log; debe decir Loaded 'SH2Coop.asi'. Revisar ubicación, LoadPlugins, LoadFromScriptsOnly, versión y antivirus. No desactives la protección global; verifica procedencia/hash del archivo.
- Error126 al cargar: suele faltar una dependencia del módulo o de otro cargador. Error193: arquitectura incorrecta. Consultar ambos logs para identificar cuál DLL falla; no descargar DLL sueltas de sitios desconocidos.
- Se carga el ASI pero no el lobby: revisar plugins/SH2Coop/SH2Coop.log, identificación del EXE y hook D3D8/ImGui. Ejecutar primero sin overlays o mods de terceros; este paquete no depende de ellos.
- No conecta: misma versión/EXE/EE, dirección y PIN correctos, puertos libres, firewall, host accesible. En el mismo PC usar 127.0.0.1:7777, no intentar alojar dos servidores en el mismo puerto.
- Mando no detectado: el log muestra la ruta de SDL3; comprobar bin/SDL3.dll. Xidi no es obligatorio ni se distribuye.
- Interfaz sin imágenes: comprobar ambas PNG conservando la estructura. El lobby dispone de fondo alternativo si faltan, pero la instalación completa incluye las dos.
- Cierre/error: adjuntar d3d8.log y plugins/SH2Coop/SH2Coop.log, versión, pasos y si ocurre con otros mods. No enviar partidas/perfiles personales innecesariamente.

## Desinstalación
Con el juego cerrado, retirar solo SH2Coop.asi y los archivos de este paquete indicados en SHA256SUMS.txt. Conservar data/save_coop si se desea mantener el progreso; no borrar data/save, d3d8.dll ni otros plugins.

## Créditos y alcance
Proyecto SH2Coop desarrollado con asistencia de Codex (OpenAI). Dear ImGui: Omar Cornut y colaboradores, licencia MIT incluida. SDL: Sam Lantinga y colaboradores, licencia zlib incluida, descarga oficial https://github.com/libsdl-org/SDL/releases/tag/release-3.4.16 . Cabeceras d3d8to9: Patrick Mours, licencia BSD incluida. Gracias al equipo de Silent Hill 2: Enhanced Edition por el cargador y su documentación. Proyecto no oficial, sin afiliación con Konami.
Este paquete no contiene ejecutables, modelos, texturas, música ni otros archivos del juego original. No es una certificación de toda la campaña: revisar TEST-RESULTS.md para distinguir pruebas realizadas de pendientes.


