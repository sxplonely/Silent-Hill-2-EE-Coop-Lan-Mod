# Auditoría 34.57 — corrección de menú

Compilación x86 /MT /O2 desde copia independiente del código. Dependencias directas reexaminadas: las mismas de34.56; sin DLL Debug. Dos imágenes y SDL coinciden con la instalación estable. No se modificó la instalación estable.

La causa reproducida es una actualización nativa parcial de opciones al terminar la búsqueda de partidas individuales. Con una sola ASI34.56 aparecieron los mismos solapamientos y ESCENAS duplicada de la captura del usuario. Se interceptan seis llamadas verificadas de actualización durante aparición e interacción del título, restaurando antes el vector nativo y reinsertando después la fila cooperativa.

El verificador ahora detecta ASI adicionales con nombre SH2Coop en plugins/scripts. No elimina nada automáticamente.

El binario final 34.57 tiene SHA256 1D6BAEFD441A67BB78BCB7D15782B0C7A2D5780BC063DDCDC92115BF4D0A852F. También se corrigió la altura de la tabla pública para reservar el botón UNIRSE. Las pruebas ejecutadas y limitaciones están en TEST-RESULTS.md.

## Base de distribución auditada en34.56 (antecedente)
# Auditoría SH2Coop 34.56

## Compilación

build_release.ps1 recompila doce archivos C++: plugin, protocolo, transporte, identidad, sesión, ImGui y backends Win32/DX9. No reutiliza la biblioteca antigua de protocolo. Salida build/Release-x86.

MSVC 19.44 / herramientas 14.44.35207, `/std:c++17 /EHsc /O2 /Ob2 /Oy- /MT /DNDEBUG`. Enlace `/DLL /MACHINE:X86 /INCREMENTAL:NO /OPT:REF /OPT:ICF /DYNAMICBASE /NXCOMPAT`. Se limpian CL, _CL_, LINK y _LINK_ para impedir opciones inyectadas. No se define SH2COOP_SAVE_LAB.

PE final: máquina 0x014C, DLL de 32 bits. Objetos con LIBCMT/libcpmt; sin bibliotecas Debug. No aparecen VCRUNTIMExxxD, MSVCPxxxD ni ucrtbased.dll. El runtime C/C++ está integrado con /MT; no requiere Visual Studio. [Referencia Microsoft](https://learn.microsoft.com/en-us/cpp/build/reference/md-mt-ld-use-run-time-library?view=msvc-170).

Advertencia preexistente C4244: conversión del nombre de un guardado a texto. Los nombres generados son numéricos; nombres renombrados manualmente con caracteres no ASCII pueden mostrarse incorrectamente. No es una dependencia Debug.

## Dependencias detectadas

| Componente | Dependencias |
|---|---|
| ASI, importaciones PE | WS2_32.dll, bcrypt.dll, VERSION.dll, USER32.dll, ole32.dll, KERNEL32.dll, SHELL32.dll, IMM32.dll |
| SDL3 x86, importaciones PE | SETUPAPI, WINMM, IMM32, VERSION, KERNEL32, USER32, GDI32, ADVAPI32, SHELL32, ole32, OLEAUT32 |
| Visual C++ | Sin importaciones dinámicas VCRUNTIME/MSVCP/UCRT en ASI ni SDL3; no se incluye vc_redist ni DLL Debug |
| Mandos | XInput de Windows y SDL3 cargada dinámicamente. SDL opcional para teclado/XInput |
| Render | Dispositivo D3D9 del wrapper d3d8.dll de EE, con d3d8to9=1 |
| Imágenes y texto | WIC de Windows, dos PNG del mod, Georgia del sistema o fuente integrada alternativa |
| Juego/EE | Ejecutable compatible e instalación EE funcional, externos al paquete |

Las DLL Windows de esas tablas no se redistribuyen. ImGui está compilado dentro del ASI. SDL3.dll sí se incluye: versión oficial 3.4.16 win32-x86, SHA256 `47D508B4232CF9462096BDB6F613A330D9A94A7EB09C305FAD073430C6531920`, obtenida de [SDL oficial](https://github.com/libsdl-org/SDL/releases/tag/release-3.4.16). Licencias SDL zlib, ImGui MIT y cabeceras d3d8to9 BSD incluidas.

MSVCR70.dll/MSVCP70.dll observadas en ejecución pertenecen al juego y no se incluyen. ucrtbase/msvcp_win/msvcrt observadas en el proceso son dependencias de otros componentes Windows/EE; no importaciones directas del ASI.

## Carga y rutas

Ubicación verificada: SH2Coop.asi junto a sh2pc.exe. EE Common/LoadModules.cpp (LoadASIPlugins/LoadPlugins), inspeccionado localmente, busca ASI en la raíz con LoadPlugins=1 y LoadFromScriptsOnly=0. La ejecución real confirmó esta carga. Los recursos y SDL pertenecen a plugins/SH2Coop.

Rutas de recursos, SDL, configuración, logs y guardados derivadas del EXE. Georgia se localiza con GetWindowsDirectoryW. No se usa una ruta C:/Users/Salazar, D:/SH2, build o PDB para funcionar. Sin órdenes del laboratorio en el ASI final. El ejemplo 127.0.0.1:7777 es editable.

SH2Coop.ini contiene solamente [Coop] EnemySync=1. Los perfiles/guardados se crean en data/save_coop y el log en plugins/SH2Coop/SH2Coop.log; no se incluyen precreados.

Se conservan los dos PNG anteriores de assets/lobby del proyecto, descritos en su historial como derivados de las referencias visuales del usuario. No se extrajeron recursos de data/sh2e para el paquete.

## Exclusiones

Sin EXE del juego, archivos data/sh2e, binkw32.dll, d3d8.dll, MSVCR70/MSVCP70, partidas, perfiles, .obj, .lib, PDB, scripts de control, código descompilado, otro cargador ASI, Xidi ni plugin de cámara. No se reemplaza d3d8.ini del usuario; README indica las claves necesarias.

No se aportó una copia identificable del ZIP descargable anterior: no se atribuye retrospectivamente una causa única a su fallo. Aquí sí se reprodujeron y corrigieron problemas concretos de instalación vacía y carga, documentados en TEST-RESULTS.md.
