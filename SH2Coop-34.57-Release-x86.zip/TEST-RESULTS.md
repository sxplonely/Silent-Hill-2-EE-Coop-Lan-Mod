# Pruebas SH2Coop 34.57 — 2026-10-22

Etapa 1: corrección del menú y distribución. No es una certificación de toda la campaña ni de conexiones entre países.

## Ejecutado en la copia independiente de Enhanced Edition

- Comparación previa de la instalación estable y el ZIP 34.56: ejecutable, cargador, ASI, SDL, PNG, configuraciones, partidas, rutas y dependencias. La instalación estable se mantuvo en modo de solo lectura.
- Reproducción real del menú defectuoso 34.56: español, una sola ASI, partidas individuales presentes. El refresco nativo tardío sobrescribía parte del vector ampliado, quitando la opción cooperativa y duplicando ESCENAS.
- 34.57: menú con y sin partidas, clic en MULTIJUGADOR y dos ciclos ESC/ENTER para reabrirlo; conserva las imágenes y el diseño del lobby anterior.
- Sala privada: PIN 9457 visible; anfitrión y tres clientes conectados, pantalla 4/4. Esta prueba precedió únicamente al último ajuste de altura de la tabla pública.
- Binario final 1D6BAEFD441A67BB78BCB7D15782B0C7A2D5780BC063DDCDC92115BF4D0A852F: descubrimiento de sala pública, botón UNIRSE completo y conexión por clic después de minimizar/restaurar. Anfitrión PID 20660 y clientes 19164/15120/25208 conectados como jugadores 1, 2 y 3.
- Ese mismo binario inició la campaña principal con las cuatro instancias. Las cuatro alcanzaron sala 1; SCENE_READY acumuló máscara 15; después de la cinemática se observaron personajes remotos y tráfico de posición/animación. No se recorrió la campaña completa.
- Prueba C++ Release x86 del vector: reproduce el refresco parcial corrupto y verifica restauración previa, navegación y estados sin partidas, parciales y completos.
- Compilación Release x86 /O2 /MT desde doce fuentes; auditoría de importaciones y objetos sin runtime Debug. SDL3 x86 se carga desde el paquete.

## Prueba del ZIP extraído desde cero

Se retiraron del laboratorio los archivos del mod y sus datos/perfiles anteriores a una carpeta de respaldo. Se extrajo el ZIP con los 13 archivos, sin DLL ni archivos auxiliares del entorno de desarrollo; el proceso se lanzó con PATH limitado a Windows/System32. Verify-Install pasó los hashes y requisitos. PID 33528 mostró el menú sin partidas previas, abrió/reabrió el lobby y creó una sala privada con PIN 1126; PID 15128 se conectó mediante ese PIN. Los registros confirmaron SDL3 desde plugins/SH2Coop/bin y la inicialización de ImGui. Una ASI duplicada de prueba fue detectada por el verificador y retirada después. Las actualizaciones finales posteriores a esa ejecución afectan solamente documentación y hashes, no los archivos de ejecución.

Los 55 archivos vigilados de la instalación estable (ejecutable, cargadores, configuraciones, plugins y partidas) conservaron sus hashes SHA256. No se desplegó nada en D:/SH2.

## Diagnóstico de la partida individual usada como control

La copia de una partida individual provocó una excepción en sh2pc.exe+0x134FD9. Se reprodujo con 34.57, con la ASI estable 34.55 copiada al laboratorio y también SIN NINGUNA ASI. En el control final sin mod, CONTINUAR estaba confirmado en el vector nativo y el depurador capturó la misma excepción: el puntero de jugador 0x1FB7C80 apuntaba al actor 0x1FB12CC (instancia 1) con raíz de esqueleto nula. No fue una regresión demostrada de esta corrección del menú. No se reparó ni modificó la partida original. El ensayo anterior que parecía cargar sin mod no confirmó gameplay y queda descartado como prueba de carga correcta.

## Alcance pendiente

Validación en la segunda PC del usuario, otras resoluciones/configuraciones, conexión entre redes distintas, P2P global, campaña completa y jefes, Born from a Wish con cuatro Marías, y ciclo completo de guardado/carga de ambos escenarios. El indicador 2/4 de algunos clientes es una limitación visual previa; el anfitrión sí muestra 4/4.

Las pruebas de red aquí son cuatro procesos en una PC usando la interfaz LAN o loopback. No equivalen a una prueba WAN. No publicar en GitHub antes de la verificación del usuario.
