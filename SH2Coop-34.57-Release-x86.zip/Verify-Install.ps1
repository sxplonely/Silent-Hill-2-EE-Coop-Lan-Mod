param([string]$GameDirectory=$PSScriptRoot)
$ErrorActionPreference='Stop'
$root=[IO.Path]::GetFullPath($GameDirectory)
foreach($line in Get-Content (Join-Path $PSScriptRoot 'SHA256SUMS.txt')){
 if($line -match '^([A-Fa-f0-9]{64})  (.+)$'){
  $file=Join-Path $root $Matches[2]
  if(!(Test-Path -LiteralPath $file)){throw "Falta: $file"}
  if((Get-FileHash -LiteralPath $file -Algorithm SHA256).Hash -ne $Matches[1]){throw "Hash diferente: $file"}
 }
}
$exe=Join-Path $root 'sh2pc.exe'
if((Get-FileHash $exe).Hash -ne 'F31A221779FADCA4DAE8FE758546ECDE8B88A88FA6E80FAD7DEE115D2EF620E8'){throw 'Ejecutable no soportado'}
$ini=Get-Content (Join-Path $root 'd3d8.ini') -Raw
if($ini -notmatch '(?m)^\s*LoadPlugins\s*=\s*1\s*$'){throw 'Activar LoadPlugins=1 en d3d8.ini'}
if($ini -match '(?m)^\s*LoadFromScriptsOnly\s*=\s*1\s*$'){throw 'Cambiar LoadFromScriptsOnly=0 para cargar ASI en la raiz'}
if($ini -notmatch '(?m)^\s*d3d8to9\s*=\s*1\s*$'){throw 'Activar d3d8to9=1 en [DirectX] para ImGui'}
$duplicates=@(Get-ChildItem (Join-Path $root 'plugins'),(Join-Path $root 'scripts') -Filter '*SH2Coop*.asi' -Recurse -File -ErrorAction SilentlyContinue); if($duplicates.Count){throw ('Copias adicionales de SH2Coop: '+(($duplicates.FullName) -join ', ')+'. Moverlas fuera del juego; conservar solo la ASI de la raiz.')} 
Write-Output ('EE: '+(Get-Item (Join-Path $root 'd3d8.dll')).VersionInfo.FileVersion)
Write-Output 'PASS: archivos/hash y ejecutable. Esta comprobacion no sustituye ejecutar el juego y probar la conexion.'

