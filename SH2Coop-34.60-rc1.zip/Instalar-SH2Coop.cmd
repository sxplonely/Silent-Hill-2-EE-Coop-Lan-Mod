@echo off
chcp 65001 >nul
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Instalar-SH2Coop.ps1"
if errorlevel 1 echo No se completo la instalacion. Revisa el mensaje anterior.
pause
