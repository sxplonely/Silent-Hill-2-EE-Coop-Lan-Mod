[CmdletBinding()]
param([string]$GameDirectory,[switch]$VerifyOnly)
$ErrorActionPreference='Stop'
if(!$GameDirectory){$GameDirectory=Read-Host 'Carpeta del juego que quieres actualizar'}
$GameDirectory=$GameDirectory.Trim().Trim('"')
$root=(Resolve-Path -LiteralPath $GameDirectory).Path.TrimEnd('\')
if(!(Test-Path -LiteralPath $root -PathType Container)){throw 'Selecciona una carpeta'}
function SafePath([string]$base,[string]$relative){
 $full=[IO.Path]::GetFullPath((Join-Path $base $relative))
 if(!$full.StartsWith($base.TrimEnd('\')+'\',[StringComparison]::OrdinalIgnoreCase) -or $relative.Contains(':')){throw 'Ruta fuera de la carpeta seleccionada'}
 $cursor=$full
 while($cursor){
  if(Test-Path -LiteralPath $cursor){
   $item=Get-Item -LiteralPath $cursor -Force
   if($item.Attributes -band [IO.FileAttributes]::ReparsePoint){throw "Enlace no permitido: $cursor"}
  }
  $parent=Split-Path -Parent $cursor;if($parent -eq $cursor){break};$cursor=$parent
 }
 return $full
}
function Hash([string]$path){return (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash}
$exe=SafePath $root 'sh2pc.exe'
if(!(Test-Path -LiteralPath $exe) -or (Hash $exe) -ne 'F31A221779FADCA4DAE8FE758546ECDE8B88A88FA6E80FAD7DEE115D2EF620E8'){throw 'Ejecutable de SH2 no compatible. Instala Enhanced Edition antes del mod.'}
foreach($name in @('d3d8.dll','d3d8.ini')){if(!(Test-Path -LiteralPath (SafePath $root $name))){throw "Falta Enhanced Edition: $name"}}
foreach($process in Get-Process -Name sh2pc,SH2CoopEosHelper -ErrorAction SilentlyContinue){
 if(!$VerifyOnly -and (!$process.Path -or $process.Path.StartsWith($root+'\',[StringComparison]::OrdinalIgnoreCase))){throw 'Cierra el juego y su auxiliar EOS antes de instalar'}
}
$package=[IO.Path]::GetFullPath($PSScriptRoot).TrimEnd('\')
$manifest=Get-Content -LiteralPath (Join-Path $package 'PAYLOAD.json') -Raw | ConvertFrom-Json
if(!$manifest.files -or $manifest.version -ne '34.60-rc1'){throw 'Manifiesto no compatible'}
$files=@($manifest.files)
foreach($f in $files){
 $source=SafePath $package ('payload\'+$f.path)
 $target=SafePath $root $f.path
 if(!(Test-Path -LiteralPath $source) -or (Hash $source) -ne $f.sha256){throw "Paquete incompleto o alterado: $($f.path)"}
 if($VerifyOnly -and (!(Test-Path -LiteralPath $target) -or (Hash $target) -ne $f.sha256)){throw "Instalacion diferente: $($f.path)"}
}
# Search only the loader's directories. Backups live outside them.
$duplicates=@()
foreach($folder in @('','plugins','scripts')){
 $dir=if($folder){SafePath $root $folder}else{$root}
 if(Test-Path -LiteralPath $dir){
  $pending=New-Object 'System.Collections.Generic.Stack[string]';$pending.Push($dir)
  while($pending.Count){
   $current=$pending.Pop()
   foreach($item in Get-ChildItem -LiteralPath $current -Force){
    if($item.PSIsContainer){
     if($folder){[void](SafePath $root $item.FullName.Substring($root.Length+1));$pending.Push($item.FullName)}
    }elseif($item.Name -like '*SH2Coop*.asi' -and $item.FullName -ne (Join-Path $root 'SH2Coop.asi')){
     [void](SafePath $root $item.FullName.Substring($root.Length+1));$duplicates+=$item.FullName
    }
   }
  }
 }
}
$iniPath=SafePath $root 'd3d8.ini'
$iniBytes=[IO.File]::ReadAllBytes($iniPath)
$iniEncoding=[Text.Encoding]::Default
$offset=0
if($iniBytes.Length -ge 3 -and $iniBytes[0] -eq 239 -and $iniBytes[1] -eq 187 -and $iniBytes[2] -eq 191){$iniEncoding=[Text.Encoding]::UTF8;$offset=3}
elseif($iniBytes.Length -ge 2 -and $iniBytes[0] -eq 255 -and $iniBytes[1] -eq 254){$iniEncoding=[Text.Encoding]::Unicode;$offset=2}
elseif($iniBytes.Length -ge 2 -and $iniBytes[0] -eq 254 -and $iniBytes[1] -eq 255){$iniEncoding=[Text.Encoding]::BigEndianUnicode;$offset=2}
$ini=$iniEncoding.GetString($iniBytes,$offset,$iniBytes.Length-$offset)
function Enabled([string]$text,[string]$name){return $text -match ('(?im)^[ \t]*'+[regex]::Escape($name)+'[ \t]*=[ \t]*1[ \t]*(?:;[^\r\n]*)?\r?$')}
if($VerifyOnly){
 if($duplicates.Count){throw 'Hay copias adicionales de SH2Coop.asi'}
 if(!(Enabled $ini 'LoadPlugins') -or !(Enabled $ini 'd3d8to9') -or (Enabled $ini 'LoadFromScriptsOnly')){throw 'Enhanced Edition debe tener LoadPlugins=1 y d3d8to9=1'}
 Write-Output 'PASS: paquete, instalacion, ejecutable y configuracion de carga verificados. No sustituye una prueba dentro del juego.'
 return
}
# Prepare edits before changing any file. Keep original encoding/line endings.
foreach($key in @('LoadPlugins','d3d8to9','LoadFromScriptsOnly')){
 $pattern='(?im)^([ \t]*'+[regex]::Escape($key)+'[ \t]*=[ \t]*)[01]([^\r\n]*)(\r?)$'
 if($ini -notmatch $pattern){throw "No se encontro $key en d3d8.ini; instala/configura Enhanced Edition primero"}
 $setting=if($key -eq 'LoadFromScriptsOnly'){'0'}else{'1'}
 $ini=[regex]::Replace($ini,$pattern,('${1}'+$setting+'${2}${3}'))
}
$backup=SafePath $root ('SH2Coop-backups\34.60-rc1-'+(Get-Date -Format yyyyMMdd-HHmmss)+'-'+[guid]::NewGuid().ToString('N').Substring(0,6))
New-Item -ItemType Directory -Path $backup -Force | Out-Null
$changes=New-Object 'System.Collections.Generic.List[object]'
function Remember([string]$path){
 $relative=$path.Substring($root.Length+1);$old=SafePath $backup $relative
 $exists=Test-Path -LiteralPath $path
 if($exists){New-Item -ItemType Directory -Path (Split-Path $old) -Force | Out-Null;Copy-Item -LiteralPath $path -Destination $old;if((Hash $old) -ne (Hash $path)){throw 'Fallo de verificacion del respaldo'}}
 $changes.Add([pscustomobject]@{path=$relative;existed=$exists})
}
function ReplaceFile([string]$source,[string]$target){
 New-Item -ItemType Directory -Path (Split-Path $target) -Force | Out-Null
 $temp=$target+'.sh2coop-'+[guid]::NewGuid().ToString('N')+'.tmp'
 Copy-Item -LiteralPath $source -Destination $temp
 # Replacing the directory entry cannot modify the contents of another hard link.
 if(Test-Path -LiteralPath $target){Remove-Item -LiteralPath $target}
 Move-Item -LiteralPath $temp -Destination $target
}
try{
 foreach($f in $files){$target=SafePath $root $f.path;Remember $target;ReplaceFile (SafePath $package ('payload\'+$f.path)) $target;if((Hash $target) -ne $f.sha256){throw 'Fallo de copia del mod'}}
 foreach($path in $duplicates){Remember $path;Remove-Item -LiteralPath $path}
 Remember $iniPath
 $iniTemp=Join-Path $backup 'loader-new.tmp';$newBytes=$iniEncoding.GetBytes($ini);if($offset){$newBytes=$iniBytes[0..($offset-1)]+$newBytes};[IO.File]::WriteAllBytes($iniTemp,$newBytes);ReplaceFile $iniTemp $iniPath;Remove-Item -LiteralPath $iniTemp
 $changes | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath (Join-Path $backup 'restore-manifest.json') -Encoding UTF8
 Write-Output "SH2Coop 34.60-rc1 instalado en: $root"
 Write-Output "Respaldo: $backup"
 Write-Output 'Guardados individuales, guardados cooperativos, controles y camara conservados.'
}catch{
 $failure=$_
 for($i=$changes.Count-1;$i -ge 0;$i--){$c=$changes[$i];$target=SafePath $root $c.path;if($c.existed){ReplaceFile (SafePath $backup $c.path) $target}elseif(Test-Path -LiteralPath $target){Remove-Item -LiteralPath $target}}
 throw $failure
}

