# SH2Coop 34.60-rc1 — validacion

Fecha: 2026-11-08. Version candidata. Parche del cierre de sesiones EOS sobre 34.59-rc1; protocolo 15 conservado.

## Correccion

- El boton de cierre usa el estado real del menu principal y no la marca persistente de una partida anterior.
- El auxiliar EOS y los trabajadores de sesion se detienen antes de liberar el estado de la partida. La limpieza tambien corre en el despachador del menu principal, que no siempre ejecuta el ciclo de juego normal.
- Se restablecen los estados de lanzamiento, guardado pendiente y lobby. Se bloquean nuevas operaciones mientras termina el cierre. La carga cooperativa y el retorno por muerte no habilitan el cierre en mitad de su transicion.

## Evidencia de esta correccion

- Release x86 /O2 /MT /DNDEBUG compilado; sin comandos de laboratorio. Importaciones PE y contenido redistribuible auditados al preparar el paquete.
- Copia aislada, EOS real con cliente publico: sala privada creada; Continue cargo el guardado cooperativo de Maria en sala195.
- El usuario completo la salida al titulo, cerro EOS, creo otra sala y volvio a cerrarla sin reiniciar SH2. Confirmo expresamente que funciona.
- Los registros corroboran: cierre con previousEpoch=3406156 y released=1; limpieza a epoch=0/released=0; otra sala EOS creada; segundo cierre y limpieza correctos.
- El compilado usado en esa comprobacion tenia SHA256 4073A56F60A47668F1F4732249666F1A623FED93D6137EF513CE6AAC6C9699CB. El binario final 9144AF80A608A921BFF1BA3E860B1097DC8E83AAD12CE82621AB659260CF0D33 agrega el bloqueo de acciones de iniciar/cargar mientras el cierre esta pendiente. Esa proteccion adicional se compilo y reviso; no se repitio la prueba visual del binario final.
- No se verifico en esta etapa un invitado remoto que vuelva a unirse a otra partida, ni una partida de cuatro personas por Internet.

## Pruebas anteriores, no repetidas en esta etapa

34.59-rc1 (2026-11-02): lista publica EOS real, exclusion de salas privadas, creacion y retirada de anuncios, carga de dependencias desde el paquete, instalador con respaldo/rollback y Windows PowerShell5. Pruebas LAN de dos y cuatro instancias para retorno compartido al checkpoint y retirada de personajes desconectados. Los puntos rojos y la muerte compartida usaron eventos/condiciones de laboratorio documentados, no un recorrido completo de la campana.

No se certifica ausencia de fallos en todas las campanas, jefes, puzzles o transiciones. No se distribuyen guardados de prueba, archivos propietarios del juego ni credenciales de desarrollo.

## Instalacion del paquete final

Instalacion autorizada en la carpeta original completada con respaldo. Verificacion de los diez archivos del mod y de la configuracion del cargador: PASS. Los 163 archivos de preservacion comprobados conservaron sus hashes. No se inicio el juego original durante esta comprobacion; el resultado visual del ciclo EOS corresponde a la copia aislada y a la confirmacion del usuario descritas arriba.
