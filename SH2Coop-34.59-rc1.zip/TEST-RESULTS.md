# SH2Coop 34.59-rc1 — validacion

Version candidata, comprobada el 2026-11-02. Los limites de cada prueba se indican a continuacion.

- Compilacion Release x86, /O2 /MT /DNDEBUG; sin comandos de laboratorio en la ASI distribuible. Auxiliar EOS x64 protocolo15.
- EOS real, cliente publico separado: crear sala privada, excluirla del listado; crear publica, encontrarla con 1/4; cerrar y comprobar su desaparicion. PASS 2026-11-02.
- Paquete instalado en copia aislada: plugin Release cargado, interfaz ImGui original, lista publica EOS con sala 5091 (1/4), sin IP, cursor normal. Creacion real desde el juego de otra sala publica, PIN6875. PASS con el NUEVO cliente publico y PATH limitado a Windows, sin variable de configuracion privada. No es una prueba de conexion entre dos personas.
- Modulos del auxiliar en ejecucion: EOSSDK, MSVCP140, VCRUNTIME140 y VCRUNTIME140_1 cargados desde plugins/SH2Coop/bin/EOS del paquete. Importaciones PE revisadas: ASI/SDL3 x86; auxiliar/SDK/runtimes x64; ninguna biblioteca Debug.
- Instalador ejecutado con Windows PowerShell 5: instalacion y verificacion de hashes PASS; rechaza actualizar el juego abierto. Fallo controlado de archivo bloqueado despues de reemplazar la ASI: restaura la ASI anterior y conserva configuracion/dependencia, PASS.
- La prueba del paquete reutilizo la copia aislada existente del juego/Enhanced Edition, reemplazando los diez archivos del mod por el contenido exacto de distribucion. No fue una instalacion nueva de Windows ni una copia nueva de todos los archivos del juego.
- Instalacion final autorizada en la carpeta personal: hashes del paquete correctos; 157 archivos preservados sin cambios (incluidos controles, camara y guardados). Arranque real de esa instalacion: SH2Coop.asi, SDL3 y camara cargados desde sus rutas locales; boton MULTIJUGADOR y lobby ImGui visibles; consulta EOS completada. El respaldo queda en SH2Coop-backups.
- LAN, dos instancias: evento nativo de punto rojo denegado al invitado; host abre menu cooperativo y guarda mediante boton real. No se camino fisicamente hasta el punto: se activo su evento nativo en el laboratorio.
- LAN, dos y cuatro instancias de Maria: salud local llevada a cero en laboratorio; retorno automatico al checkpoint, salud80, misma sala195 y nuevos actores. Probados disparadores de invitado y host. No es prueba de golpe letal natural de enemigo ni EOS WAN.
- Desconexion voluntaria de un invitado y cierre forzado de otra instancia: personajes retirados de las restantes. PASS.
- Sesion/codec: cuatro plazas, rechazo de quinta conexion, validacion de roster y limites de anuncios. PASS. No se probaron cinco identidades EOS reales.
- Pruebas anteriores de inventarios, puzzles, personajes y enemigos se conservan; no equivalen a recorrer ambos capitulos completos.
- Pendiente: partida de varios PC por EOS con esta version, golpe letal natural, recarga del capitulo de James, todos los jefes/puzzles/transiciones. No se declara ausencia total de bugs.

El primer ensayo de muerte artificial fallo por generar un impacto sin ID de ataque. Se retiro esa simulacion incorrecta: la muerte compartida usa el indicador nativo de fin de muerte y la limpieza/carga del motor. Las repeticiones descritas arriba pasaron.
