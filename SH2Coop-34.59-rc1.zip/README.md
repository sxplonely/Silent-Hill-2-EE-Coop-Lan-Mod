# SH2Coop 34.59-rc1

Version candidata de pruebas para Silent Hill 2: Enhanced Edition. Cooperativo para hasta cuatro jugadores, por LAN o por Internet mediante Epic Online Services (EOS). No incluye el juego ni Enhanced Edition.

## Requisitos

- Tu propia instalacion de Silent Hill 2 PC con Enhanced Edition funcional.
- Ejecutable compatible SHA256 F31A221779FADCA4DAE8FE758546ECDE8B88A88FA6E80FAD7DEE115D2EF620E8. El instalador lo comprueba.
- Windows 10/11 de 64 bits para ejecutar el auxiliar EOS, aunque SH2 y el plugin son x86.
- Todos deben instalar exactamente este paquete y usar la misma version de Enhanced Edition. Protocolo de red 15; incompatible con paquetes anteriores.
- Internet para EOS. El paquete contiene un cliente EOS publico limitado, autorizado para distribucion; no necesitas una cuenta de desarrollador ni copiar configuraciones privadas.
- SH2Coop y su auxiliar usan runtime C++ estatico Release. El SDK EOS usa los runtimes x64 msvcp140, vcruntime140 y vcruntime140_1, incluidos junto al auxiliar. XAudio2_9Redist es una importacion diferida para audio/voz no utilizado por este mod y no se incluye. Las DLL incluidas y las dependencias de Windows se enumeran en DEPENDENCIES.json. Otros mods, la camara y Enhanced Edition pueden tener requisitos propios.

## Instalacion

1. Cierra SH2 en la carpeta que vayas a actualizar.
2. Extrae TODO el ZIP a una carpeta, no ejecutes el instalador dentro del ZIP.
3. Abre Instalar-SH2Coop.cmd e indica la carpeta que contiene sh2pc.exe.
4. El instalador comprueba los hashes, respalda los archivos que reemplaza y retira las copias duplicadas de SH2Coop.asi. Activa LoadPlugins=1, LoadFromScriptsOnly=0 y d3d8to9=1 en d3d8.ini.
5. Abre sh2pc.exe. Selecciona MULTIJUGADOR y RED: INTERNET (EOS) o RED: LAN.

Se instala SH2Coop.asi junto a sh2pc.exe, sus recursos y sus dependencias bajo plugins/SH2Coop. Se conservan tus controles, camara, configuraciones personales y guardados. El respaldo queda en SH2Coop-backups, con un registro de los archivos anteriores. No reemplaces d3d8.dll con archivos de otros paquetes.

## Jugar

- EOS publico: CREAR SERVIDOR, CREAR SALA PUBLICA. Los demas usan SERVIDORES PUBLICOS y F5 para actualizar, seleccionan tu sala y pulsan UNIRSE.
- EOS privado: crea sala privada y comparte el PIN de cuatro digitos. Las IP no aparecen en la interfaz; se usa el relay de Epic.
- Una sala admite cuatro jugadores. Una sala llena no admite nuevas conexiones; una lista antigua puede necesitar F5.
- F9 abre los guardados cooperativos. Solo el host guarda. Los puntos rojos abren el mismo menu para el host; los invitados no pueden abrir guardados individuales mediante ellos.
- Si alguien muere, el host coordina el retorno del grupo al ultimo guardado cooperativo. Se crea un primer checkpoint al estabilizarse una partida nueva; conserva guardados manuales de tu progreso.
- Los inventarios y consumibles son personales. Solo se retiran del grupo los objetos de puzzle confirmados como utilizados. Los guardados cooperativos estan en data/save_coop, separados de data/save.
- Al abandonar o perder la conexion se retira el personaje remoto.

## Problemas comunes

- No aparece MULTIJUGADOR: comprueba LoadPlugins=1, LoadFromScriptsOnly=0 y d3d8to9=1, y que no haya otra SH2Coop.asi antigua. Ejecuta `powershell -NoProfile -ExecutionPolicy Bypass -File .\Instalar-SH2Coop.ps1 -GameDirectory "TU CARPETA" -VerifyOnly`.
- Faltan recursos o auxiliar EOS: extrae todo el ZIP y reinstala. No basta copiar la ASI.
- No aparecen salas: todos necesitan este protocolo, red EOS seleccionada y una sala PUBLICA abierta. Una privada se busca con PIN. F5 refresca la lista.
- Error EOS: revisa plugins/SH2Coop/SH2Coop.log; no publiques archivos eos.private.ini ni eos.dev.ini. Una variable local SH2COOP_EOS_CONFIG puede hacer que tu PC use otra configuracion en lugar de la publica.
- La camara de tercera persona es un mod separado y no se incluye en este paquete. Si ya esta instalada, se conserva.
- Para desinstalar: con el juego cerrado, retira los archivos enumerados en PAYLOAD.json y restaura los originales del respaldo. Conserva data/save_coop si quieres mantener tus partidas. No borres otros mods.

## Alcance de pruebas

Consulta TEST-RESULTS.md. Es una version candidata: las pruebas locales no garantizan ausencia de fallos en toda la campana ni sustituyen una partida de cuatro personas por Internet. La lista EOS si se comprobo contra el servicio real. No se certifican todos los jefes, puzzles ni transiciones.

## Creditos

SH2Coop: proyecto de Salazar, desarrollado con asistencia de OpenAI Codex. Dependencias: Dear ImGui, SDL3, Epic Online Services SDK; avisos en licenses/. Silent Hill 2 y sus recursos pertenecen a sus titulares y no forman parte de esta descarga. Enhanced Edition y el mod de camara se distribuyen por separado. Se conserva el diseno de lobby existente.
